#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef _OPENMP
  #include <omp.h>
#else
  #define omp_get_thread_num() 0
#endif

int main(int argc, char **argv) {
  // LECTURA

  int i,j;
  struct timespec ini,fin; double transcurrido;

  if(argc < 3) {
    fprintf(stderr,"Falta num\n");
    exit(-1);
  }
  int n = atoi(argv[1]); 
  omp_sched_t kind = atoi(argv[2]);
  int modifier;
  if (argc==4) modifier = atoi(argv[3]);
  else omp_get_schedule(&kind, &modifier);
  
  omp_set_schedule(kind, modifier);

  int *v1,*v2;
  v1 = (int*) malloc(n*sizeof(double));
  v2 = (int*) malloc(n*sizeof(double));

  int **M;
  M = (int**) malloc(n*sizeof(int*));
  for(i=0;i<n;i++) 
    M[i] = (int*)malloc(n*sizeof(int));
  
  printf("\nEl chunk utilizado será: %d\n", modifier);
      if(kind==1) printf("El tipo de asignacion utilizado será: static\n");
      if(kind==2) printf("El tipo de asignacion utilizado será: dynamic\n");
      if(kind==3) printf("El tipo de asignacion utilizado será: guided\n");
      if(kind==4) printf("El tipo de asignacion utilizado será: auto\n");
      if(kind==5) printf("El tipo de asignacion utilizado será: runtime\n");

  for(i=0;i<n;i++)
    v1[i]=i+1;

  int num=1;
  for(i=0;i<n;i++){
    for(j=0;j<n;j++){
      if(j>i) M[i][j]=0;
      else { M[i][j]=num; num++; }
    }
  }
  
  // 4. Cálculo resultado
  clock_gettime(CLOCK_REALTIME,&ini);
  
  #pragma omp parallel for default(none) private(i,j) shared(n,v1,v2,M) schedule(runtime)
  for (i=0; i<n; i++) {
    v2[i]=0;
    for (j=0; j<=i; j++) {
      v2[i]+=M[i][j]*v1[j];
    }
  }

  clock_gettime(CLOCK_REALTIME,&fin);
  transcurrido=(double) (fin.tv_sec-ini.tv_sec)+(double) ((fin.tv_nsec-ini.tv_nsec)/(1.e+9));

    printf("Tiempo: \%11.9f\n",transcurrido);
    printf("v2[0]: %d, v2[n-1]: %d\n",v2[0],v2[n-1]);

  free(M);
  free(v1);
  free(v2);
}

