#!/bin/bash

#Órdenes para el sistema de colas
#SBATCH --job-name=HelloOMP   # Asigna un nombe al trabajo
#SBATCH --partition=ac        # Asigna una cola (partición)
#SBATCH --account=ac          # Asigna un account
#SBATCH --ntasks=1            # Procesos por nodo
#SBATCH --cpus-per-task=12    # Número de hebras por proceso
#SBATCH --hint=nomultithread  # Solo una hebra por core físico
#SBATCH --exclusive           # No se comparte el cluster con otros trabajos de la cola
#SBATCH --output=HelloOMP.log # Nombre del fichero de salida

export OMP_DYNAMIC=FALSE
export OMP_NUM_THREADS=1
echo "Ejecucion -> static"

for (( i = 100; i <= 1500; i +=200 )); do
	./pmm-OpenMP $i
done

echo -e "\n"
export OMP_DYNAMIC=TRUE
declare -a threads=(2)

for i in "${threads[@]}"
do
	export OMP_NUM_THREADS=$i
	echo -e "\n Ejecucion -> dynamic  |  Num. threads = $i"
	for (( j = 100; j <= 1500; j+=200 )); do
		./pmm-OpenMP $j
	done
done