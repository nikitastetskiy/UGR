#include <stdlib.h> // atoi(), malloc() y free()
#include <stdio.h> // printf()
#include <time.h>   // clock_gettime()
#ifdef _OPENMP
  #include <omp.h>    // OpenMP 
#else
  #define omp_get_thread_num() 0
  #define omp_get_num_threads() 1
#endif

int main(int argc, char **argv) {

   if(argc < 2){
   	fprintf(stderr,"Falta el tamaño\n");
   	exit(-1);
 	}

   unsigned int N = atoi(argv[1]);
   long long unsigned int **B, **C, **A;
   int i, j, k, chunk;
   omp_sched_t kind;
   double t_ini, t_fin, tiempo;

  if(N < 0){
   	fprintf(stderr,"Falta el tamaño\n");
   	exit(-1);
 	}
  
  // INICIALIZACION
   A = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   B = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   C = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   for(long long unsigned int i=0 ; i<N ; i++){
    A[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   	B[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   	C[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   }

  #pragma omp parallel
  {
    #pragma omp for firstprivate(j) schedule(runtime)
    for(i=0 ; i<N ; i++)
   	for(j=0 ; j<N ; j++){
        A[i][j]=0;
      	B[i][j]=i+j;
      	C[i][j]=i+j;
   	}
    #pragma omp single
    t_ini = omp_get_wtime();
   #pragma omp for schedule(runtime)
   for (i=0 ; i<N; i++)
		for(j=0 ; j<N ; j++)
			for(k=0 ; k<N ; k++)
				A[i][j] += B[i][k] * C[k][j];

    #pragma omp single
    t_fin = omp_get_wtime();
  }
   
  tiempo = t_fin - t_ini;

   printf("Tiempo(seg): %11.9f\t | Tamaño de la Matriz: %u\n",tiempo,N);
	printf("A[0][0]=%llu\nA[%d][%d]=%llu \n", \
		A[0][0], N-1, N-1, A[N-1][N-1]);	

	for(int i=0 ; i<N ; i++){
		free(B[i]);
		free(C[i]);
		free(A[i]);
	}
	free(B);
  free(C);
  free(A);

	return 0;
}