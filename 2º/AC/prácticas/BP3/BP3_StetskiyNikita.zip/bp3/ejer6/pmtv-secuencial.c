#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#ifdef _OPENMP
    #include <omp.h>
#else
    #define omp_get_thread_num() 0
#endif

main(int argc, char **argv){
    int i, j, num=1;
    struct timespec ini,fin; double tiempo;
    if(argc < 2){
        printf("FALTAN ARGUMENTOS [fila/columnba]\n");
        exit(1);   
    }

    int n = atoi(argv[1]);
    int *A,*B;
    int **M;
    A = (int*) malloc(n*sizeof(double));
    B = (int*) malloc(n*sizeof(double));
    M = (int**) malloc(n*sizeof(int*));
    for(i=0;i<n;i++) 
        M[i] = (int*)malloc(n*sizeof(int));

    // INICIALIZACION
    for(i=0;i<n;i++)
        A[i]=i+1;

    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(j>i) M[i][j]=0;
        else { M[i][j]=num; num++; }
        }
    }
    
    // MULTIPLICACION
    clock_gettime(CLOCK_REALTIME,&ini);
    for (i=0; i<n; i++) {
        B[i]=0;
        for (j=0; j<=i; j++) {
            B[i]+=M[i][j]*A[j];
        }
    }
    clock_gettime(CLOCK_REALTIME,&fin);
    tiempo=(double) (fin.tv_sec-ini.tv_sec)+(double) ((fin.tv_nsec-ini.tv_nsec)/(1.e+9));
    printf("Tiempo: \%11.9f\n",tiempo);
      printf("B[0]: %d, B[n-1]: %d\n",B[0],B[n-1]);

    for(i=0; i<n; i++)
        free(M[i]);
    free(A);
    free(B);
    free(M);

    return(0);
}

