#include <stdlib.h> // atoi(), malloc() y free()
#include <stdio.h> // printf()
#include <time.h>   // clock_gettime() 

int main(int argc, char **argv) {

  struct timespec cgt1,cgt2; 
  double tiempo;

   if(argc < 2){
   	fprintf(stderr,"Falta el tamaño\n");
   	exit(-1);
 	}

   unsigned int N = atoi(argv[1]);
   long long unsigned int **B, **C, **A;
   int i, j, k;

  if(N < 0){
   	fprintf(stderr,"Falta el tamaño\n");
   	exit(-1);
 	}
  
  // INICIALIZACION
   A = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   B = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   C = (long long unsigned int**) malloc(N*sizeof(long long unsigned int*));
   for(long long unsigned int i=0 ; i<N ; i++){
    A[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   	B[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   	C[i] = (long long unsigned int*) malloc(N*sizeof(long long unsigned int));
   }

   for(i=0 ; i<N ; i++)
   	for(j=0 ; j<N ; j++){
        A[i][j]=0;
      	B[i][j]=i+j;
      	C[i][j]=i+j;
   	}

   clock_gettime(CLOCK_REALTIME,&cgt1);

   // CALCULO

   for (i=0 ; i<N; i++)
		for(j=0 ; j<N ; j++)
			for(k=0 ; k<N ; k++)
				A[i][j] += B[i][k] * C[k][j];


   clock_gettime(CLOCK_REALTIME,&cgt2);
   tiempo=(double) (cgt2.tv_sec-cgt1.tv_sec)+
     (double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

   printf("Tiempo(seg): %11.9f\t | Tamaño de la Matriz: %u\n",tiempo,N);
	printf("A[0][0]=%llu\nA[%d][%d]=%llu \n", \
		A[0][0], N-1, N-1, A[N-1][N-1]);	

	for(int i=0 ; i<N ; i++){
		free(B[i]);
		free(C[i]);
		free(A[i]);
	}
	free(B);
  free(C);
  free(A);

	return 0;
}