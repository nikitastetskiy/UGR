#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
int main(int argc, char** argv){

	// Lectura
	
	int i,j;
	double **A, *B, *C, t;
	if(argc<2){
		fprintf(stderr,"Falta iteraciones");
	}	
	unsigned int N=atoi(argv[1]);
	A=(double**)malloc(N*sizeof(double*));
	B=(double*)malloc(N*sizeof(double));
	C=(double*)malloc(N*sizeof(double));

	// Inicialición

	if((A==NULL)||(B==NULL)||(C==NULL)){
		printf("Error al reservar memoria");
		exit(-2);
	}
	for(i=0; i<N; i++){
		A[i]=(double*)malloc(N*sizeof(double));
		if(A[i]==NULL){
			printf("Error al reservar memoria");
			exit(-3);
		}
	}

	// Calculo

	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			A[i][j]=0.1*i-0.1*j;
		}
		C[i]=0.0;
		B[i]=0.1*i;
	}
	t=omp_get_wtime();
	#pragma omp parallel for private(i,j)
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			C[i]+=A[i][j]+B[j];
		}
	}

	// Resultado

	t=omp_get_wtime()-t;
	printf("Resultado: \nC[0] = %.4f  \nC[%d] = %.4f    \nTiempo: %10.8f s\n",C[0], N-1,C[N-1], t);
	for(i=0; i<N; i++){
		free(A[i]);
	}

	// Eliminacion de memoria

	free(A);
	free(B);
	free(C);
	return(0);
}
