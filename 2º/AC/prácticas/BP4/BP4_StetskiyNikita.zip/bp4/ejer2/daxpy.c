#include <stdlib.h> // atoi(), malloc() y free()
#include <stdio.h>  // printf()
#include <time.h>   // clock_gettime()

int main(int argc, char **argv)
{

  struct timespec inicio, final;
  double tiempo;

  if (argc < 2)
  {
    fprintf(stderr, "Falta el tamaño\n");
    exit(-1);
  }

  unsigned int a, i, N;
  a = 5;
  N = atoi(argv[1]);

  if (N > 200000000)
    N = 200000000;	// para que no de error en la asignacion de matrices
  if (N <= 0)
  {
    fprintf(stderr, "\n[ERROR] - El tamaño tiene que ser mayor que 0\n");
    exit(-1);
  }

  long long unsigned int *x, *y;
  x = (long long unsigned int *)malloc(N * sizeof(long long unsigned int));
  y = (long long unsigned int *)malloc(N * sizeof(long long unsigned int));

  if ((x == NULL) || (y == NULL))
  {
    printf("Error en la reserva de espacio para las matrices\n");
    exit(-2);
  }

  for (i = 0; i < N; i++)
    x[i] = i;

  clock_gettime(CLOCK_REALTIME, &inicio);

  for (i = 0; i < N; i++)
    y[i] = a * x[i] + y[i];

  clock_gettime(CLOCK_REALTIME, &final);
  tiempo = (double)(final.tv_sec - inicio.tv_sec) +
           (double)((final.tv_nsec - inicio.tv_nsec) / (1.e+9));

  printf("Tiempo(seg.):%11.9f\t / Tamaño de N:%u\n", tiempo, N);

  free(x);
  free(y);

  return 0;
}
