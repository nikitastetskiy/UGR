#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct
{
  int a;
  int b;
} s[5000];

int main()
{
  int ii, i, X1, X2, X3, X4, X5, X6, X7, X8;
  long long unsigned int R[40000];

  struct timespec inicio, final;
  double tiempo;

  for (int x = 0; x < 5000; x++)
  {
    s[x].a = x;
    s[x].b = x;
  }

  clock_gettime(CLOCK_REALTIME, &inicio);

  for (ii = 0; ii < 40000; ii++)
  {
    X1 = 0;
    X2 = 0;
    for (i = 0; i < 5000; i += 4)
    {
      X1 += 2 * s[i].a + ii;
      X2 += 2 * s[i + 1].a + ii + 1;
      X3 += 2 * s[i + 2].a + ii + 2;
      X4 += 2 * s[i + 3].a + ii + 3;
    }
    for (i = 0; i < 5000; i += 4)
    {
      X5 += 3 * s[i + 1].b - ii;
      X6 += 3 * s[i + 1].b - ii + 1;
      X7 += 3 * s[i + 1].b - ii + 2;
      X8 += 3 * s[i + 1].b - ii + 3;
    }

    R[ii] = X1 < X5 ? X1 : X5;
    R[ii] = X2 < X6 ? X2 : X6;
    R[ii] = X3 < X7 ? X3 : X7;
    R[ii] = X4 < X8 ? X4 : X8;
  }

  clock_gettime(CLOCK_REALTIME, &final);
  tiempo = (double)(final.tv_sec - inicio.tv_sec) +
           (double)((final.tv_nsec - inicio.tv_nsec) / (1.e+9));

  printf("Tiempo(seg.):%11.9f \n", tiempo);
  printf("R[0]=%llu\t R[39999]=%llu\n", R[0], R[39999]);

  return 0;
}

